package com.example.enums;

public enum JobStatus {
    OPEN,
    CLOSED,
    PAUSED,
    FILLED
}
