package com.example.enums;

public enum PaidStatus {
    PENDING,
    PAID,
    FAILED
}
