package com.example.enums;
public enum PaymentStatus {
    SUCCESS,
    FAILED,
    PENDING,
    REFUNDED
}
