package com.example.enums;

public enum PaymentType {
    RAZORPAY,
    CREDIT_CARD,
    DEBIT_CARD,
    UPI,
    NETBANKING
}
