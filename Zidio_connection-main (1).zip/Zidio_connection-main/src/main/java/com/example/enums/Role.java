package com.example.enums;

public enum Role {
    ROLE_ADMIN,
    ROLE_RECRUITER,
    ROLE_STUDENT,
    ROLE_USER
}
