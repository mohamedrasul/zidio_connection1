package com.example.enums;
public enum Status {
    PENDING,
    APPLIED,
    ACCEPTED,
    REJECTED,
    CLOSED
}
