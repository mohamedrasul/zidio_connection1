package com.example.zidio;

public @interface EnableEurekaClient {
}
